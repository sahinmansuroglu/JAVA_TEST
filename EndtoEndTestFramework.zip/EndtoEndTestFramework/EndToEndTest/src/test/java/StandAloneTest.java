import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class StandAloneTest {
    public static  void main(String [] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver=new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://rahulshettyacademy.com/client");
        driver.findElement(By.cssSelector("#userEmail")).sendKeys("test12@test.com");
        driver.findElement(By.cssSelector("#userPassword")).sendKeys("Test1234");
        driver.findElement(By.cssSelector("input#login")).click();

        WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mb-3")));
        List<WebElement> products= driver.findElements(By.cssSelector(".mb-3"));

        WebElement searchedProduct=products.stream().filter(product->
                product.findElement(By.cssSelector("b")).getText().equals("ZARA COAT 3")
        ).findFirst().orElse(null);

        searchedProduct.findElement(By.cssSelector(" .card-body button:last-of-type")).click();



        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#toast-container")));
        // wait ng-animating
       // wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".ng-animating")));
        // the belloe script is more effective than above
        wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.cssSelector(".ng-animating"))));

        driver.findElement(By.cssSelector("[routerlink*='cart']")).click();

       // System.out.println(searchedProduct.getText());
        Thread.sleep(3000);
    }
}
