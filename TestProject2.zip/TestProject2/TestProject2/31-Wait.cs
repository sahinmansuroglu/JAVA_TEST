﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;

namespace TestProject2
{
     class ImpicityDeneme
    {
        IWebDriver driver;
        WebDriverWait wait;
        [SetUp]
        public void StartBrowser()
        {
            //new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
             new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
            //driver = new FirefoxDriver();
            driver = new ChromeDriver();
            //implicit  wait 5 seconds can be declared globally

            //wait = new WebDriverWait(driver, new TimeSpan(0, 0, 30));

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(25);

            driver.Manage().Window.Maximize();
            driver.Url = "https://rahulshettyacademy.com/loginpagePractise/";
        }


        [Test]
        public void LocatorsIdentification1()
        {
            driver.FindElement(By.Id("username")).SendKeys("rahulshetty");
            driver.FindElement(By.Name("password")).SendKeys("12345678");
            driver.FindElement(By.XPath("//input[@value='Sign In']")).Click();
            WebDriverWait wait = new WebDriverWait(driver,TimeSpan.FromSeconds(8));
            //Sign in işleminde buton Signin in oluyor. Tekrar sign in butonu ekrana geldiğinde hata mesajı veriyor
            // Aşağıdaki kod ile buton Sign İn olanan kadar bekletiliyor.
            //wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementValue(driver.FindElement(By.Id("signInBtn")), "Sign In"));
           
            //Aşağıdaki kodlar alert mesajı ekrana gelene kadar bekletiliyor.
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[@class='alert alert-danger col-md-12']")));
            String errorMessage = driver.FindElement(By.XPath("//div[@class='alert alert-danger col-md-12']")).Text;
            driver.FindElement(By.Id("username")).SendKeys(errorMessage);
        }
     }
}
