﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;

namespace TestProject2
{

    //SelectorsHub ve ChroPath chrome için gerekli
    /// <summary>
    /// https://rahulshettyacademy.com/loginpagePractise/
    /// </summary>
    public class Locators
    {
        //xpath , Css, id, classname, name, tagname,linktext
        IWebDriver driver;
        [SetUp]
        public void StartBrowser()
        {
            new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
          
             driver = new ChromeDriver();
            //implicit  wait 5 seconds can be declared globally
           // driver.Manage().Timeouts().ImplicitWait =TimeSpan.FromSeconds(25); 

            driver.Manage().Window.Maximize();
            driver.Url = "https://rahulshettyacademy.com/loginpagePractise/";
        }
         

        [Test]
        public void LocatorsIdentification()
        {
            driver.FindElement(By.Id("username")).SendKeys("rahulshettyacademy");
            driver.FindElement(By.Id("username")).Clear();
            driver.FindElement(By.Id("username")).SendKeys("rahulshetty");
            driver.FindElement(By.Name("password")).SendKeys("12345678");
            //css selector & xpath
            // tagname[attribute='value']
            // driver.FindElement(By.CssSelector("input[value='Sign In']")).Click();

            // xpath yapısı--> //tagName[@attribute='value'] 

            // #id #terms  -- class name --> css .classname

            //CSS class name ---> ".text-info span:nth-child(1) input" 
            // X-Path --->     "//label[@class='text-info']/span/input"
            // #terms
            // driver.FindElement(By.XPath("//div[@class='form-group'][5]/label/span/input")).Click();
            driver.FindElement(By.CssSelector("#terms")).Click();


            driver.FindElement(By.XPath("//input[@value='Sign In']")).Click();

            //Implicit wait tanımlandığı için thread sleep'e gerek kalmadı
            //Thread.Sleep(3000);
            //class="alert alert-danger col-md-12"
            //  String errorMessage=driver.FindElement(By.ClassName("alert-danger")).Text;

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(8));
            //Sign in işleminde buton Signin in oluyor. Tekrar sign in butonu ekrana geldiğinde hata mesajı veriyor
            // Aşağıdaki kod ile buton Sign İn olanan kadar bekletiliyor.
            //wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementValue(driver.FindElement(By.Id("signInBtn")), "Sign In"));

            //Aşağıdaki kodlar alert mesajı ekrana gelene kadar bekletiliyor.
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[@class='alert alert-danger col-md-12']")));
            String errorMessage = driver.FindElement(By.ClassName("alert-danger")).Text;

            TestContext.Progress.WriteLine(errorMessage);

            TestContext.WriteLine(errorMessage);

            driver.FindElement(By.Id("username")).SendKeys(errorMessage);
            IWebElement link = driver.FindElement(By.LinkText("Free Access to InterviewQues/ResumeAssistance/Material"));

            String hrefAttr=link.GetAttribute("href");
            string expectedURL="https://rahulshettyacademy.com/#/documents-request";
            Assert.AreEqual(expectedURL, hrefAttr);
           //validate url of the text 


        }

    }
}
