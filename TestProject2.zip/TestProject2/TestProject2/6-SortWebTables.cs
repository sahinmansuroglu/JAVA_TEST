﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;

namespace TestProject2
{
    public class SortWebTables
    {
        IWebDriver? driver;
        [SetUp]
        public void StartBrowser()
        {
            new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());

            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait =TimeSpan.FromSeconds(5); 

            driver.Manage().Window.Maximize();
            driver.Url = "https://rahulshettyacademy.com/seleniumPractise/#/offers";
        }

        [Test]
        public void SortTables1()
        {
            IList<IWebElement> cbox = driver.FindElements(By.CssSelector("select option"));
            foreach (IWebElement item in cbox)
            {
                if (item.GetAttribute("value").Equals("10"))
                {
                    item.Click();

                }
            }
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//tr/th[1]/span[1]")).Click();


        }
        [Test]
        public void SortTables2()
        {
            ArrayList a = new ArrayList();
           
            IWebElement dropdown = driver.FindElement(By.Id("page-menu"));
            SelectElement s = new SelectElement(dropdown);
            s.SelectByText("20");
           


            //step-1 get all veggie names into arraylist A
            IList<IWebElement> vegggiNames=driver.FindElements(By.XPath("//tr/td[1]"));
            vegggiNames.ToList().ForEach(x => a.Add(x.Text));
            //step-2 Sort tihs arraylist -A
            a.Sort();
            foreach (var item in a)
            {
                TestContext.Progress.WriteLine(item);
            }
            
            //step-3 go and  click column
            Thread.Sleep(3000);

            //th[aria - label *= 'fruit name']  burada * regular expression'da contains işlemi
            //th[contains(@aria-label,'fruit name')]  yukarıdaki yapının xpath ile gösterimi
            //Aşağıdaki seçim yerine yukarıdaki 2 seçenek de kullanılabilir.

            driver.FindElement(By.XPath("//tr/th[1]/span[1]")).Click();
            //step-4 Get all veggie namse into arraylist B
            ArrayList b = new ArrayList();
            IList<IWebElement> vegggiNamesSorted = driver.FindElements(By.XPath("//tr/td[1]"));
            vegggiNamesSorted.ToList().ForEach(x => b.Add(x.Text));
            //step-5 arraylist A to B = equal

            TestContext.Progress.WriteLine(a.Equals(b)); ;

            Assert.AreEqual(a, b,"Sıralama Hatası");
        }
    }
}
